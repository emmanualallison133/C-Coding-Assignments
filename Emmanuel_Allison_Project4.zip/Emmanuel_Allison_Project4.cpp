// Name: Emmanuel Allison
// Date: March 7, 2017
// Purpose: This program provides the user with options to calculate their telegram bill, translate a message into morse code, or 
// process a data file to display telegram bill records depending on their menu selection. 
// The user is also given the option to quit and close the program at the menu. The program will continue to run until the user selects the quit option.


# include <iostream>		
# include <iomanip>		// For setprecision in the telegram calculations and processing data file option.				
# include <fstream>		// Allows use for the open ifstream file stream class and the inputFile object.
using namespace std;

//Global constants rate of what each block of 5 and 1 words will be worth.
	const double RATE_5 = 1.50;
	const double RATE_1 = .50;

//Function Prototypes
	double telegramBill(int);
	void morseCode(string);
	void dataFile();
	

int main()
{

// Establishes constant integer variables for the option variable to equal and start their respective functions.
	const int TELEGRAM_BILL = 1;
	const int MORSE_CODE = 2;
	const int DATA_FILE = 3;
	const int QUIT = 4;
	
//Reads the user's menu selection.	
	int option;	
				
	int words_sent;
	double amount_owed;
// 
	string input;	
	
cout << "Welcome to Western Union Telegraph Company";

do
{
	cout << endl << endl;
	cout << "1 - Process Telegram Bill" << endl;
	cout << "2 - Translate to Morse Code" << endl;
	cout << "3 - Process a Data File" << endl;
	cout << "4 - Quit" << endl << endl;
	
	cout << "Enter your choice: ";
cin >> option;	
	
	//Displays the menu again if the user enters an invaild menu option and gives them an unlimited number of chances to enter a valid menu choice.	
	while (option < TELEGRAM_BILL || option > QUIT) 	
		{
			cout << endl;
			cout << option << " is not a valid choice" << endl << endl << endl;
			
			cout << endl;
			cout << "1 - Process Telegram Bill" << endl;
			cout << "2 - Translate to Morse Code" << endl;
			cout << "3 - Process a Data File" << endl;
			cout << "4 - Quit" << endl << endl;
	
			cout << "Enter your choice: ";
		cin >> option; 
		}
	
	if (option != QUIT)		//Proceeds to the option's respective function if the user's option does not equal the quit option.
	{
		
		if (option == TELEGRAM_BILL) 
		{
			cout << endl;
			cout << "Enter the number of words sent: ";			//Asks for the number of words sent by the customer
			cin >> words_sent;
			
			amount_owed = telegramBill(words_sent);
			
			//Displays the amount due as currency.
			cout << "Amount Owed: $" << setprecision(2) << fixed << amount_owed << endl << endl;
		}
			
	 
		else if (option == MORSE_CODE) 
			{
				cout << "Enter a message: ";		// Prompts the user for a message.
				cin.ignore();						// *Note how cin.ignore is used to skip a character in the keyboard buffer.*
				getline(cin, input);			    // Stores the entire line of the customer's message, including spaces.
				
				cout << "Translation:"; 			// Displays the translation label first
				morseCode(input);	
				
			}
		else if (option == DATA_FILE) 
			dataFile();			

	}	
					
} while (option != QUIT); 	//Tells the program to quit once the user selects the quit option.

//Displays the closing message
cout << endl;
cout << "Thank you.  Closing program.";
		
return 0;		
}

double telegramBill(int words_sent)
{
	int blocks_of_5;
	int blocks_of_1;
	double amount_owed;
					
		while (words_sent < 0)
		{
			cout << endl;
			cout << "                                     *ERROR!*\n";
			cout << "Please enter a positive integer for the number of words sent: ";
			cin >> words_sent;
		}
					
				// Divides the words sent by the user into groups of 5 and its remainders
					blocks_of_5 = words_sent / 5;
					blocks_of_1 = words_sent % 5;
					
				// Multiples the constant doubles by their respective group of 5 and single words, then add them to get
				// the amount of money due.
					amount_owed = (blocks_of_5 * RATE_5) + (blocks_of_1 * RATE_1);
					
				return amount_owed;
}

void morseCode(string input)
{
	
// Establishes strings to hold the customer's message and the morse code of each of its letters
	string code;
				
				//Initializes the count variable as zero, repeats the switch function for as long as there 
				// are letters to read, and	adds 1 to the count each time.
				for (int count = 0; count < input.length(); count++)
				{
					switch (input.at(count))		//Reads the letter that the count is equal to and goes through different cases to translate it into morse code.
					{
						default:
							code = "'";		//Displays an apostrophe if none if none of the cases match (an "'" cannot be a case)
						break;
						
						case 'a':
						case 'A': 
							code = " . -";		//The code string stores the morse code equivalent of the respective switch case letter
						break;
						
						case 'b':
						case 'B':
							code = " - . . .";
						break;	
						
						case 'c':
						case 'C':
							code = " - . - .";
						break;
						
						case 'd':
						case 'D': 
							code = " - . .";
						break;
						
						case 'e':
						case 'E': 
							code = " .";
						break;
						
						case 'f':
						case 'F': 
							code = " . . - .";
						break;
						
						case 'g':
						case 'G': 
							code = " - - .";
						break;
						
						case 'h':
						case 'H': 
							code = " . . . .";
						break;
						
						case 'i':
						case 'I':
							code = " . .";
						break;
						
						case 'j':
						case 'J': 
							code = " . - - -";
						break;
						
						case 'k':
						case 'K': 
							code = " - . -";
						break;
						
						case 'l':
						case 'L': 
							code = " . - . .";
						break;
						
						case 'm':
						case 'M':
							code = " - -";
						break;
						
						case 'n':
						case 'N':
							code = " - .";
						break;
						
						case 'o':
						case 'O': 
							code = " - - -";
						break;
						
						case 'p':
						case 'P': 
							code = " . - - .";
						break;
						
						case 'q':
						case 'Q': 
							code = " - - . -";
						break;
						
						case 'r':
						case 'R': 
							code = " . - .";
						break;
						
						case 's':
						case 'S': 
							code = " . . .";
						break;
						
						case 't':
						case 'T':
							code = " -";
						break;
						
						case 'u':
						case 'U': 
							code = " . . -";
						break;
						
						case 'v':
						case 'V':
							code = " . . . -";
						break;
						
						case 'w':
						case 'W': 
							code = " . - -" ;
						break;
						
						case 'x':
						case 'X':
							code = " - . . -";
						break;
						
						case 'y':
						case 'Y': 
							code = " - . - -";
						break;
						
						case 'z':
						case 'Z': 
							code = " - . .";
						break;
						
					//If the next letter cannot be translated into morse code, it will display the untranslated character.
						case ',':			 
							code = ",";
						break;
						
						case '!': 
						code = "!";
						break;
						
						case '?': 
						code = "?";
						break;
						
						case ' ': 
						code = "   ";
						break;
						
						case ':': 
						code = ":";
						break;
						
						case '&':
						code = "&";
						break;
						
						case ';':
						code = ";";
						break;
						
						case '.':
						code = ".";
						break;
						
						case '`':
						code = "`";
						break;
						
						case '~':
						code = "~";
						break;
						
						case '(':
						code = "(";
						break;
						
						case ')':
						code = ")";
						break;
						
						case '@':
						code = "@";
						break;
						
						case '#':
						code = "#";
						break;
						
						case '+':
						code = "+";
						break;
						
						case '$':
						code = "$";
						break;
						
						case '%':
						code = "%";
						break;
						
						case '^':
						code = "^";
						break;
						
						case '*':
						code = "*";
						break;
						
						case '<':
						code = "<";
						break;
						
						case '>':
						code = ">";
						break;
						
						case '{':
						code = "{";
						break;
						
						case '}':
						code = "}";
						break;
						
						case '[':
						code = "[";
						break;
						
						case ']':
						code = "]";
						break;
						
						case '|':
						code = "|";
						break;
						
						case '/':
						code = "/";
						break;
					}
					cout << code; 	//Displays each letter's morse code equivelent each time the "for" function is performed.
				}
					cout << endl << endl;
}

void dataFile()
{
	// Establishes string variables to hold the customer's information.
	string name, street_address, city, state, zip_code;
	
	int words_sent;
	int blocks_of_5;
	int blocks_of_1;
	double amount_owed;
	double total = 0;
	
	ifstream inputFile; 		//reads data from the file we wish to use
	
	cout << endl;
				
				inputFile.open("TelegramData.txt");		//Opens the TelegramData.txt to read from.
				
				while (inputFile >> name) 		//Repeats as long as there are names to read in the Telegram file. Also reads the first name of each bill.
				{	
					cout << name;				//Displays the first name of each bill.
					
				//Reads  the customer's last name by storing the last name line in the same name string and displays the name again as the last name.
					getline(inputFile, name);	
					cout << name << endl;
					
				//Reads and displays the customer's street address by storing the street address lines of the file in the street_address string.
					getline(inputFile, street_address);
					cout << street_address << endl;
					
				//Reads the customer's city, state, and zip code by storing the city, state, and zip code line of the file in their respective strings.
					getline(inputFile, city);
					getline(inputFile, state);
					getline(inputFile, zip_code);
			
				//Reads and displays the number of words the customer has sent.
					inputFile >> words_sent;

				//Calculates the amount due in the same process as TELEGRAM_BILL
					blocks_of_5 = words_sent / 5;
					blocks_of_1 = words_sent % 5;
					
					amount_owed = (blocks_of_5 * RATE_5) + (blocks_of_1 * RATE_1);
					
					total += amount_owed;
					
				//Displays the customer's city, state, zip code that was collected from the file and the calculated amount that is due.
					cout << city << ", "<< state << " " << zip_code << endl;
					cout << "Amount Owed: $" << setprecision(2) << fixed << amount_owed << endl << endl;
				}
				
				cout << "The total cost of all the telegram bills is $" << total << endl;
				inputFile.close();		//Closes the Telegram.txt file
}

